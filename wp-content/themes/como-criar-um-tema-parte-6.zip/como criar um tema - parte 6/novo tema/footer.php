	<div id="footer">
		<p>&copy; 2012 - Todos os Direitos Reservados</p>
		<?php wp_footer(); ?>
	</div>
	
</div>
	
</body>
</html>