		<div id="sidebar">
			<ul class="widget">
				<h3>Widget</h3>
				<li><a href="#">Página 1</a></li>
				<li><a href="#">Página 2</a></li>
				<li><a href="#">Página 3</a></li>
				<li><a href="#">Página 4</a></li>
			</ul>
		
			<ul class="widget">
				<h3>Widget</h3>
				<li><a href="#">Categoria 1</a></li>
				<li><a href="#">Categoria 2</a></li>
				<li><a href="#">Categoria 3</a></li>
				<li><a href="#">Categoria 4</a></li>
			</ul>
		</div>
